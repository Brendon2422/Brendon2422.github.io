A Pen created at CodePen.io. You can find this one at http://codepen.io/iamtheWraith/pen/vGWMVQ.

 An idea for a project I am working on.