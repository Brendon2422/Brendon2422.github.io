A Pen created at CodePen.io. You can find this one at http://codepen.io/n400/pen/emGgOG.

 Rudimentary combination of jquery fixed header on scroll and nav active section class effect

"Fixed Header On Scroll Effect" forked from [sayed rafeeq](http://codepen.io/syedrafeeq/)'s Pen [FIXED HEADER - ON SCROLL  EFFECT](http://codepen.io/syedrafeeq/pen/sDnKg/).

"Scroll Active 2" forked from [Xabi](http://codepen.io/xabiwan/)'s Pen [Scroll active 2](http://codepen.io/xabiwan/pen/myWJmP/).

Forked from [sayed rafeeq](http://codepen.io/syedrafeeq/)'s Pen [FIXED HEADER - ON SCROLL  EFFECT](http://codepen.io/syedrafeeq/pen/sDnKg/).